from setuptools import setup

setup(
    name='clients_package',
    version='1.0',
    description='package for clients management',
    author='Carlo M Solis',
    author_email='carlos.solis97@gmail.com',

    packages=['clients_package']
)
